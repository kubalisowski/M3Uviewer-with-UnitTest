﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace PlaylistMain
{
    class PathFinder : Config
    {
        // Parameters of the object
        public string date { get; set; }
        public string client { get; set; }
        public string[] dayMonth;
        public string finalPath;
        // Other vars
        private string nowDate = DateTime.Now.ToString();
        // All characters - months names
        Regex rgx = new Regex(@".*", RegexOptions.Compiled | RegexOptions.IgnoreCase);


        // Default: date - today; client - lokalne; 
        public PathFinder()
        {
            date = nowDate;
            client = "Lokalne";
        }
            
        private string GetPath(string[] daymonth)
        {
            string thePath;
            string[] dirs;
            //Date ddMM
            dayMonth[0] = String.Concat(date[0], date[1]);
            dayMonth[1] = String.Concat(date[3], date[4]);

            
            
            if (date == nowDate)
            {
                thePath = basicPath + "2020\\";
                // 0 - sunday, 1 - monday, 6 - saturday
                int day = (int)DateTime.Now.DayOfWeek + 1;
                dirs = Directory.GetDirectories(thePath);

                // Get path of folder basing on date - folder name contain day number
                foreach (string item in dirs)
                {
                    if ((int)item[1] == day)
                    {
                        thePath = item;
                    }
                    break;
                }
                // Final path today folder
                return thePath;
            }
            else
            {
                switch (client)
                {
                    case "Agora":

                        break;

                    case "Eurozet":

                        break;

                    case "Lokalne":

                        break;
                }
                
            }

        }

       

        public void GetM3U(string datemonth)
        {
            string[] dirs = System.IO.Directory.GetDirectories(datemonth[0] + ".*");

            string fullpath = basic_path + String.Concat(datemonth[0], datemonth[1]);
            string[] files = System.IO.Directory.GetFiles(basic_path, "*.m3u");
        }
    }
}
