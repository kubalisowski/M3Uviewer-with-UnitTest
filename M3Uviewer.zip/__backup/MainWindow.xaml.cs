﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.ComponentModel;
using System.Data;
using Microsoft.Win32;

namespace PlaylistMain
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnMoveUp.Content = char.ConvertFromUtf32(0x2191);
            btnMoveDown.Content = char.ConvertFromUtf32(0x2193);
        }

        ///// OBJECTS /////
        PathFinder PathFinder = new PathFinder();
        M3U M3U = new M3U();
        LoadOptions LoadOptions = new LoadOptions();
        ///////////////////

        /// VARIABLES ////
        // Variable at the top to update ListView (data source)
        ObservableCollection<M3UItem> ItemsM3U = new ObservableCollection<M3UItem>();
        /////////////////

        ///// METHODS /////
        ///TEST
        private List<M3UItem> linesOfContent(M3UItem MainItem)
        {
            List<M3UItem> lines = new List<M3UItem>();
            foreach (string line in MainItem.AllContent)
            {
                M3UItem lineItem = new M3UItem();
                lineItem.Name = MainItem.Name;
                lineItem.AllContent.Add(line);
                /// List of M3UItems with one line
                lines.Add(lineItem);
            }

            return lines;
        }

        // Reload ListBox with filenames
        private void reloadListBox(PathFinder PathFinder, M3U M3U, ListBox filesListBox)
        {
            // Get path to certain day
            string path = PathFinder.GetPath();
            // Get m3u files info (name with ext, full path etc.)
            M3U.FilesInfoList(path);
            // Converting List<string> to array
            string[] files = M3U.FileNameNoExt(M3U.M3Ufiles).ToArray();
            // Prepare listbox and fill it
            filesListBox.Items.Clear();
            for (int i = 0; i < files.Length; i++)
            {
                filesListBox.Items.Add(files[i]);
            }
        }

        // Load today folder as default
        private void WindowLoaded(object sender, RoutedEventArgs e)
        {
            reloadListBox(PathFinder, M3U, filesListBox);
        }

        // Get selected M3U
        private List<string> selectedItems()
        {
            // Linq used - https://stackoverflow.com/questions/22950545/fill-string-array-with-listbox-selected-items-in-c-sharp
            List<string> items = (from string s in filesListBox.SelectedItems select s).ToList();

            return items;
        }

        // Display selected M3U(s) content
        private void loadM3U(LoadOptions LoadOptions)
        {
            List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
            //ObservableCollection<M3UItem> items_m3u = new ObservableCollection<M3UItem>();
            //M3USingleItem M3USingleItem = new M3USingleItem();
            // Class M3UItem to create objects to be bind to ListView as array
            foreach (FileInfo file in selectedM3Uinfo)
            {
                M3UItem M3UItem = new M3UItem(file, LoadOptions);
                ItemsM3U.Concat(linesOfContent(M3UItem));
                //M3UItem M3UItem = new M3UItem(file, LoadOptions);
                //foreach (M3UItem item in M3UItem.LinesOfContent)
                //{
                //    items_m3u.Add(item);
                //}
                //M3UItem M3UItem = new M3UItem(file, LoadOptions);
                //items_m3u.Add(M3UItem);
            }

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ItemsM3U);
            PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
            view.GroupDescriptions.Add(groupDescription);

            /// loadedM3U listview items source
            loadedM3U.ItemsSource = ItemsM3U;
        }
        //////// Overload
        /// While choosing new file
        private void loadM3U(LoadOptions LoadOptions, M3UItem SingleFileItem)
        {
            List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
            ObservableCollection<M3UItem> ItemsM3U = new ObservableCollection<M3UItem>();
            M3USingleItem M3USingleItem = new M3USingleItem();
            // Class M3UItem to create objects to be bind to ListView as array
            foreach (FileInfo file in selectedM3Uinfo)
            {
                M3UItem M3UItem = new M3UItem(file, LoadOptions);                   
                ItemsM3U.Concat(M3USingleItem.LinesOfContent(M3UItem));
            }

            ItemsM3U.Add(SingleFileItem);

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ItemsM3U);
            PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
            view.GroupDescriptions.Add(groupDescription);

            /// loadedM3U listview items source
            loadedM3U.ItemsSource = ItemsM3U;
        }

        
        /////////////////////////


        //////// CONTROLS ////////

        ///// CALENDAR /////
        private void monthCalendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
            {
                // To get day.month.year only: 01.02.2020
                PathFinder.date = monthCalendar.SelectedDate.ToString().Substring(0, 11);
                reloadListBox(PathFinder, M3U, filesListBox);
            }

        ///// RADIO /////
        private void radioAgora_Checked(object sender, RoutedEventArgs e)
        {
            PathFinder.client = Agora.Name;
            reloadListBox(PathFinder, M3U, filesListBox);
        }

        private void radioEurozet_Checked(object sender, RoutedEventArgs e)
        {
            PathFinder.client = Eurozet.Name;
            reloadListBox(PathFinder, M3U, filesListBox);
        }

        private void radioLokalne_Click(object sender, RoutedEventArgs e)
        {
            PathFinder.client = Lokalne.Name;
            reloadListBox(PathFinder, M3U, filesListBox);
        }

        ///// BUTTONS /////
        private void btnDeselectAll_Click(object sender, RoutedEventArgs e)
        {
            filesListBox.UnselectAll();
        }

        private void btnSelectAll_Click(object sender, RoutedEventArgs e)
        {
            filesListBox.SelectAll();
        }

        private void btnLoadM3U_Click(object sender, RoutedEventArgs e)
        {
            loadM3U(LoadOptions);
        }

        // https://stackoverflow.com/questions/12540457/moving-an-item-up-and-down-in-a-wpf-list-box
        private void btnMoveUp_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = loadedM3U.SelectedItem;
            Console.WriteLine(selectedItem.GetType());

            //foreach (M3UItem item in selectedItems)
            //{
            //    Console.WriteLine(item.Content);
            //}

            //if (selectedIndex > 0)
            //{
            //    var itemToMoveUp = this.ItemsM3U[selectedIndex];
            //    ItemsM3U.RemoveAt(selectedIndex);
            //    ItemsM3U.Insert(selectedIndex - 1, itemToMoveUp);
            //    //loadedM3U.SelectedIndex = selectedIndex - 1;
            //}
        }

        private void btnMoveDown_Click(object sender, RoutedEventArgs e)
        {
            
        }

        // Choose file
        private void btnLoadFile_Click(object sender, RoutedEventArgs e)
        {
            // https://www.c-sharpcorner.com/UploadFile/mahesh/openfiledialog-in-wpf/
            OpenFileDialog LoadFileDialog = new OpenFileDialog();
            LoadFileDialog.Multiselect = true;
            bool? result = LoadFileDialog.ShowDialog();
            //... equals: Nullable<bool> result = LoadFile.ShowDialog();

            if (result == true)
            {
                foreach (ListViewItem item in loadedM3U.SelectedItems)
                {
                    
                    
                }

                //M3UItem fileItem = new M3UItem(LoadFileDialog.FileName, LoadOptions);
                //var displayedM3U = loadedM3U.ItemsSource;

                //loadM3U(LoadOptions, fileItem);


                //ObservableCollection<M3UItem> ItemsM3U = new ObservableCollection<M3UItem>();
                //var enumerator = loadedM3U.ItemsSource.GetEnumerator();
                //test = new ObservableCollection<M3UItem>();

                //Console.WriteLine(fileItem.Content);
                //foreach (string c in fileItem.Content)
                //{
                //    Console.WriteLine(c);
                //}

                //foreach (M3UItem m in displayedM3U)
                //{
                //    ItemsM3U.Add(m);
                //}
                //ItemsM3U.Add(fileItem);
                //loadedM3U.ItemsSource = ItemsM3U;
            }
        }

        ///// LISTVIEW /////
        private void filesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
            {

            }

        ///// CHECKBOXES | LOAD OPTIONS /////
        private void showComments_Checked(object sender, RoutedEventArgs e)
        {
            LoadOptions.ShowComments = (bool)showComments.IsChecked;
        }

        private void showPath_Checked(object sender, RoutedEventArgs e)
        {
            LoadOptions.ShowPath = (bool)showPath.IsChecked;
        }

        private void loadedM3U_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int selectedItem = loadedM3U.SelectedIndex;
            Console.WriteLine(selectedItem);
            //foreach (ListViewItem )
            //{

            //}
        }

    }
    }

