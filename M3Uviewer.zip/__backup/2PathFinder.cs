﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

//BACKUP

namespace PlaylistMain
{
    class PathFinder : Config
    {
        // PARAMETERS
        public string date { get; set; }
        public string client { get; set; }
        public string[] dayMonth = new string[2];
        public string finalPath;
        // Other vars
        private string nowDate = DateTime.Now.ToString();

        // Regex to select months names
        Regex rgx = new Regex(@".*", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        //// Class constructor
        // Default: date - today; client - lokalne; 
        public PathFinder()
        {
            date = nowDate;
            client = "Lokalne";
            finalPath = "";
        }
            

        public string GetPath()
        {
            // Vars
            //TODO: delete below ?
            string[] dirs;
            string[] dayMonth = new string[2] { "", "" };
            // Date ddMM (day\month)
            //TODO: create another method to not duplicate code
            dayMonth[0] = String.Concat(date[0], date[1]);
            dayMonth[1] = String.Concat(date[3], date[4]);


            //// TODAY
            if (date == nowDate)
            {
                // 0 - sunday, 1 - monday, 6 - saturday
                int day = (int)DateTime.Now.DayOfWeek;
                dirs = Directory.GetDirectories(todayPath);
                // REGEX
                Regex rgx = new Regex(String.Format(".*0{0}", day.ToString()), RegexOptions.Compiled | RegexOptions.IgnoreCase);
                Match dayMatch;

                // Get folder path containing day number
                //TODO: error handle
                foreach (string item in dirs)
                {
                    dayMatch = rgx.Match(item);
                    if (dayMatch.Success == true)
                    {
                        finalPath = item;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                return finalPath;
            }
            //// OTHER DAY + check client selected
            else
            {
                //TODO: create function to not multiple the code for each case
                switch (client)
                {
                    case "Agora":
                        dirs = Directory.GetDirectories(notTodayPath);
                        // REGEX
                        Regex rgxAgora = new Regex(String.Format(".*{0}", dayMonth[1]), RegexOptions.Compiled | RegexOptions.IgnoreCase);
                        Match monthMatchAgora;
                        // Get folder path containing month number
                        //TODO: error handle
                        foreach (string item in dirs)
                        {
                            monthMatchAgora = rgx.Match(item);
                            if (monthMatchAgora.Success == true)
                            {
                                dirs = Directory.GetDirectories(item);
                                // Get folder path containing day number
                                rgxAgora = new Regex(String.Format(".*{0}", dayMonth[0]), RegexOptions.Compiled | RegexOptions.IgnoreCase);
                                finalPath = item;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        return finalPath;

                    case "Eurozet":
                        dirs = Directory.GetDirectories(eurozetPath);
                        // REGEX
                        Regex rgxEurozet = new Regex(String.Format(".*{0}", dayMonth[1]), RegexOptions.Compiled | RegexOptions.IgnoreCase);
                        Match monthMatchEurozet;
                        // Get folder path containing month number
                        //TODO: error handle
                        foreach (string item in dirs)
                        {
                            monthMatchEurozet = rgxEurozet.Match(item);
                            if (monthMatchEurozet.Success == true)
                            {
                                dirs = Directory.GetDirectories(item);
                                // Get folder path containing day number
                                rgxEurozet = new Regex(String.Format(".*{0}", dayMonth[0]), RegexOptions.Compiled | RegexOptions.IgnoreCase);
                                finalPath = item;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        return finalPath;

                    //TODO: implement action
                    case "Lokalne":
                        return finalPath;
                }
                
            }
            return finalPath;
        }
        
        //public string[] GetM3U()
        //{
        //    string m3uPath = GetPath(date, client);
        //    string[] m3uList = Directory.GetFiles(m3uPath, "*.m3u");
        //    return m3uList;
        //}
    }
}
