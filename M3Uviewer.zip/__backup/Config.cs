﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaylistMain
{
    class Config
    {
        private string basic_path;
        public string basicPath
        {
            get
            {
                basicPath = basic_path;
                return basicPath;
            }
            set
            {
                basic_path = "C:\\Users\\Sferis\\source\\repos\\PlaylistMain\\FOLDERS\\current day\\Archiwum\\Public\\RADIO\\reklamy m3u\\";
                //TODO: production path "\\Archiwum\\Public\\RADIO\\reklamy m3u\\";
            }
        }

        // TODO: find folder-month name by regex
        //private string[] all_months = new string[10];
        //public string[] months
        //{
        //    get
        //    {
        //        months = all_months;
        //        return months;
        //    }
        //    set
        //    {
        //        months = { "styczeń", "luty", "marzec", "kwiecień", };
        //    }
        //}
        
        
    }
}

