﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace PlaylistMain
{
    class M3UItem : M3U
    {
        //// ENCAPSULATION ////
        private FileInfo m3uInfo;
        public FileInfo M3uInfo
        {
            get
            {
                return m3uInfo;
            }
            set
            {
                m3uInfo = value;
            }
        }

        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        private List<string> allContent;
        public List<string> AllContent
        {
            get
            {
                return allContent;
            }
            set
            {
                allContent = value;
            }
        }

        private List<M3UItem> linesOfContent;
        public List<M3UItem> LinesOfContent
        {
            get
            {
                return linesOfContent;
            }
            set
            {
                linesOfContent = value;
            }
        }

        public M3UItem()
        {

        }
        ///// CONSTRUCTOR
        // M3U file
        public M3UItem(FileInfo m3uFile, LoadOptions LoadOptions)
        {
            Name = FileNameNoExt(m3uFile.Name);
            List<string> fullContent = ReadFullM3U(m3uFile);
            /// ALL
            if (LoadOptions.ShowPath == true && LoadOptions.ShowComments == true)
            {
                AllContent = fullContent;
            }
            /// FILE NAMES
            else if (LoadOptions.ShowPath == false && LoadOptions.ShowComments == false)
            {
                AllContent = HideComments(HidePath(fullContent));
            }
            /// PATH
            else if (LoadOptions.ShowPath == true && LoadOptions.ShowComments == false)
            {
                AllContent = HideComments(fullContent);
            }
            /// COMMENTS
            else if (LoadOptions.ShowPath == false && LoadOptions.ShowComments == true)
            {
                AllContent = HidePath(fullContent);
            }

            //foreach (string line in AllContent)
            //{
            //    ////M3UItem Item = new M3UItem();
            //    //Item.Name = Name;
            //    //Item.AllContent.Add(line);
            //    //LinesOfContent.Add(Item);
            //}

        }
        //// OVERLOAD
        // single file
        public M3UItem(string fullPath, LoadOptions LoadOptions)
        {
            AllContent.Add(fullPath);
            if (LoadOptions.ShowPath == false)
            {
                AllContent = HidePath(AllContent);
            }
        }
        ////////
        


    }
}
