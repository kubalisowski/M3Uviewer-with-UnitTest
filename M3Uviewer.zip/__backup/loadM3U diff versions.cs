private void loadM3U(LoadOptions LoadOptions)
{
    ItemsM3U.Clear();
    List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());

    //// Class M3UItem to create objects to be bind to ListView as array
    foreach (FileInfo file in selectedM3Uinfo)
    {
        M3UItem m3UItem = new M3UItem(file, LoadOptions);

        foreach (string line in m3UItem.AllContent)
        {
            M3USingleItem m3USingleItem = new M3USingleItem(m3UItem.Name, line);
            Console.WriteLine(line);
            ItemsM3U.Add(m3USingleItem);
        }          
    }

    //CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ItemsM3U);
    //PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
    //view.GroupDescriptions.Add(groupDescription);


    //// loadedM3U listview items source
    loadedM3U.ItemsSource = ItemsM3U;


    //// 1
    //List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
    //ObservableCollection<M3UItem> items_m3u = new ObservableCollection<M3UItem>();

    ////// Class M3UItem to create objects to be bind to ListView as array
    //foreach (FileInfo file in selectedM3Uinfo)
    //{
    //    M3UItem M3UItem = new M3UItem(file, LoadOptions);
    //    items_m3u.Add(M3UItem);
    //}

    //CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(items_m3u);
    //PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
    //view.GroupDescriptions.Add(groupDescription);

    ////// Update ObservableCollection variable 
    //ItemsM3U = items_m3u;

    ////// loadedM3U listview items source
    //loadedM3U.ItemsSource = ItemsM3U;

    //// 2
    //List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
    //ObservableCollection<M3UItem> items_m3u = new ObservableCollection<M3UItem>();

    //// Class M3UItem to create objects to be bind to ListView as array
    //foreach (FileInfo file in selectedM3Uinfo)
    //{
    //    M3UItem M3UItem = new M3UItem(file, LoadOptions);
    //    items_m3u.Add(M3UItem);
    //}

    //CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(items_m3u);
    //PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
    //view.GroupDescriptions.Add(groupDescription);

    //// Update ObservableCollection variable 
    //ItemsM3U = items_m3u;

    ///// loadedM3U listview items source
    //loadedM3U.ItemsSource = ItemsM3U;

    //// 3
    //List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
    //ObservableCollection<M3UItem> items_m3u = new ObservableCollection<M3UItem>();
    //ItemsM3U.Clear();

    //// Class M3UItem to create objects to be bind to ListView as array
    //foreach (FileInfo file in selectedM3Uinfo)
    //{

    //    M3UItem MainM3UItem = new M3UItem(file, LoadOptions);
    //    foreach (string line in MainM3UItem.AllContent)
    //    {
    //        M3UItem SingleM3UItem = new M3UItem(MainM3UItem.Name, line);
    //        ItemsM3U.Add(SingleM3UItem);
    //    }
    //}

    //CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(items_m3u);
    //PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
    //view.GroupDescriptions.Add(groupDescription);

    //// Update ObservableCollection variable 
    //ItemsM3U = items_m3u;

    //loadedM3U.ItemsSource = ItemsM3U;
}

////////// Overload
///// While choosing new file
//private void loadM3U(LoadOptions LoadOptions, M3UItem SingleFileItem)
//{
//    List<FileInfo> selectedM3Uinfo = M3U.GetSelectedM3UInfo(selectedItems());
//    ObservableCollection<M3UItem> ItemsM3U = new ObservableCollection<M3UItem>();
//    M3USingleItem M3USingleItem = new M3USingleItem();
//    // Class M3UItem to create objects to be bind to ListView as array
//    foreach (FileInfo file in selectedM3Uinfo)
//    {
//        M3UItem M3UItem = new M3UItem(file, LoadOptions);                   
//        ItemsM3U.Concat(M3USingleItem.LinesOfContent(M3UItem));
//    }

//    ItemsM3U.Add(SingleFileItem);

//    CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ItemsM3U);
//    PropertyGroupDescription groupDescription = new PropertyGroupDescription("Name");
//    view.GroupDescriptions.Add(groupDescription);

//    /// loadedM3U listview items source
//    loadedM3U.ItemsSource = ItemsM3U;
//}
/////////////////////////